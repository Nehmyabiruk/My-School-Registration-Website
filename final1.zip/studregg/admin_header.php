<!-- Simple header placeholder -->
<header><h1>Student Panel</h1></header>